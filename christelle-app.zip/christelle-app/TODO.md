TODO
geolocation + autocomplete d'adresse
requête en fonction :
  - de l'endroit où on va
  - du temps de disponibilité
  - de la categorie choisie
calcul d'itineraires