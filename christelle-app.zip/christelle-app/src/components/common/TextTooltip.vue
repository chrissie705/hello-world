<template>
  <div class="TextTooltip
  ">
    <slot/>
  </div>
</template>

<style scoped>
.TextTooltip
 {
  padding: 1em;
  
}
</style>
