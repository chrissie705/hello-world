export default {
  state: {
    travelMode: undefined,
    departureLatitude: 0,
    departureLongitude: 0,
    arrivalLatitude: 0,
    arrivalLongitude: 0,
  },
  mutations: {

  },
  actions: {

  }
}
