export default {
  state: {
    activities: []
  },
  mutations: {

  },
  actions: {

  }
}
